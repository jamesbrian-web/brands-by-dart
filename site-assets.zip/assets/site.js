
const menu = document.querySelector('.menu');
if (menu) {
 menu.addEventListener('click', () => {
  const expanded = menu.getAttribute('aria-expanded') === 'true';
  menu.setAttribute('aria-expanded', String(!expanded));
 });
}
const form = document.querySelector('#enquiry');
if (form) {
 const service = new URLSearchParams(location.search).get('service');
 const select = form.elements.service;
 if ([...select.options].some(option => option.value === service)) select.value = service;
 form.addEventListener('submit', event => event.preventDefault());
}
